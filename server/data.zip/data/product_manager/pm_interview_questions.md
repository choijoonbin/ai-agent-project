Evaluation Criteria for Backend Developers:
- 기술 역량 (40%)
- 문제 해결 능력 (30%)
- 커뮤니케이션 (20%)
- 업무 경험 (10%)

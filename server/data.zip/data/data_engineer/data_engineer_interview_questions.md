1. Parquet vs CSV 차이?
2. 데이터 파티셔닝 전략 설명
3. Kafka Consumer Group 동작 방식?
4. Spark 성능 최적화 기법?

1. Pod가 CrashLoopBackOff인 경우?
2. Terraform과 CloudFormation 차이?
3. Zero-downtime 배포 방법?

Backend Interview Questions (Sample)

1. 서비스 장애가 발생했을 때 어떻게 접근하시나요?
2. 트랜잭션 격리수준 4가지 설명
3. 인덱스를 잘못 사용하면 어떤 문제가 발생하나요?
4. Redis를 사용하는 이유는?
5. REST API와 RPC의 차이점?
6. 대규모 트래픽 대응 경험 설명

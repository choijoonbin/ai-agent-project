1. React의 렌더링 최적화 방법?
2. Virtual DOM이 실제 DOM과 다른 점?
3. CORS가 무엇인가?
4. 브라우저 동작 원리를 설명해보세요.
